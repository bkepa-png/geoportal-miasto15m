"""
Model exported as python.
Name : Analiza_dostepnosci_15m
Group : 
With QGIS : 34415
"""

from typing import Any, Optional

from qgis.core import QgsProcessing
from qgis.core import QgsProcessingAlgorithm
from qgis.core import QgsProcessingContext
from qgis.core import QgsProcessingFeedback, QgsProcessingMultiStepFeedback
from qgis.core import QgsProcessingParameterVectorLayer
from qgis.core import QgsProcessingParameterFeatureSink
from qgis import processing


class Analiza_dostepnosci_15m(QgsProcessingAlgorithm):

    def initAlgorithm(self, config: Optional[dict[str, Any]] = None):
        self.addParameter(QgsProcessingParameterVectorLayer('granice_miasta', 'granice_miasta', types=[QgsProcessing.TypeVectorPolygon], defaultValue=None))
        self.addParameter(QgsProcessingParameterVectorLayer('poi_edukacja', 'poi_edukacja', types=[QgsProcessing.TypeVectorPoint], defaultValue=None))
        self.addParameter(QgsProcessingParameterVectorLayer('poi_handel', 'poi_handel', types=[QgsProcessing.TypeVectorPoint], defaultValue=None))
        self.addParameter(QgsProcessingParameterVectorLayer('poi_transport', 'poi_transport', types=[QgsProcessing.TypeVectorPoint], defaultValue=None))
        self.addParameter(QgsProcessingParameterVectorLayer('poi_zdrowie', 'poi_zdrowie', types=[QgsProcessing.TypeVectorPoint], defaultValue=None))
        self.addParameter(QgsProcessingParameterVectorLayer('poi_zielen', 'poi_zielen', types=[QgsProcessing.TypeVectorPoint], defaultValue=None))
        self.addParameter(QgsProcessingParameterFeatureSink('Przyciete_hex', 'przyciete_hex', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, defaultValue=None))
        self.addParameter(QgsProcessingParameterFeatureSink('Cnt_edukacja', 'cnt_edukacja', type=QgsProcessing.TypeVectorPolygon, createByDefault=True, supportsAppend=True, defaultValue=None))
        self.addParameter(QgsProcessingParameterFeatureSink('Cnt_zdrowie', 'cnt_zdrowie', type=QgsProcessing.TypeVectorPolygon, createByDefault=True, supportsAppend=True, defaultValue=None))
        self.addParameter(QgsProcessingParameterFeatureSink('Cnt_handel', 'cnt_handel', type=QgsProcessing.TypeVectorPolygon, createByDefault=True, supportsAppend=True, defaultValue=None))
        self.addParameter(QgsProcessingParameterFeatureSink('Cnt_zielen', 'cnt_zielen', type=QgsProcessing.TypeVectorPolygon, createByDefault=True, supportsAppend=True, defaultValue=None))
        self.addParameter(QgsProcessingParameterFeatureSink('Cnt_transport', 'cnt_transport', type=QgsProcessing.TypeVectorPolygon, createByDefault=True, supportsAppend=True, defaultValue=None))
        self.addParameter(QgsProcessingParameterFeatureSink('Siatka_analiza_15m', 'siatka_analiza_15m', optional=True, type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, defaultValue=None))

    def processAlgorithm(self, parameters: dict[str, Any], context: QgsProcessingContext, model_feedback: QgsProcessingFeedback) -> dict[str, Any]:
        # Use a multi-step feedback, so that individual child algorithm progress reports are adjusted for the
        # overall progress through the model
        feedback = QgsProcessingMultiStepFeedback(11, model_feedback)
        results = {}
        outputs = {}

        # Utw�rz siatk�
        alg_params = {
            'CRS': 'ProjectCrs',
            'EXTENT': parameters['granice_miasta'],
            'HOVERLAY': 0,
            'HSPACING': 250,
            'TYPE': 4,  # Sze�ciok�t (poligon)
            'VOVERLAY': 0,
            'VSPACING': 250,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['UtwrzSiatk'] = processing.run('native:creategrid', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            return {}

        # Przytnij
        alg_params = {
            'INPUT': outputs['UtwrzSiatk']['OUTPUT'],
            'OVERLAY': parameters['granice_miasta'],
            'OUTPUT': parameters['Przyciete_hex']
        }
        outputs['Przytnij'] = processing.run('native:clip', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['Przyciete_hex'] = outputs['Przytnij']['OUTPUT']

        feedback.setCurrentStep(2)
        if feedback.isCanceled():
            return {}

        # Centroidy
        alg_params = {
            'ALL_PARTS': False,
            'INPUT': outputs['Przytnij']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Centroidy'] = processing.run('native:centroids', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            return {}

        # Bufory wektorowe
        alg_params = {
            'DISSOLVE': False,
            'DISTANCE': 1000,
            'EXPLODE_COLLECTIONS': False,
            'FIELD': None,
            'GEOMETRY': 'geometry',
            'INPUT': outputs['Centroidy']['OUTPUT'],
            'OPTIONS': None,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['BuforyWektorowe'] = processing.run('gdal:buffervectors', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(4)
        if feedback.isCanceled():
            return {}

        # Policz punkty w poligonie
        alg_params = {
            'CLASSFIELD': None,
            'FIELD': 'cnt_edukacja',
            'POINTS': parameters['poi_edukacja'],
            'POLYGONS': outputs['BuforyWektorowe']['OUTPUT'],
            'WEIGHT': None,
            'OUTPUT': parameters['Cnt_edukacja']
        }
        outputs['PoliczPunktyWPoligonie'] = processing.run('native:countpointsinpolygon', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['Cnt_edukacja'] = outputs['PoliczPunktyWPoligonie']['OUTPUT']

        feedback.setCurrentStep(5)
        if feedback.isCanceled():
            return {}

        # Policz punkty w poligonie
        alg_params = {
            'CLASSFIELD': None,
            'FIELD': 'cnt_zdrowie',
            'POINTS': parameters['poi_zdrowie'],
            'POLYGONS': outputs['PoliczPunktyWPoligonie']['OUTPUT'],
            'WEIGHT': None,
            'OUTPUT': parameters['Cnt_zdrowie']
        }
        outputs['PoliczPunktyWPoligonie_2'] = processing.run('native:countpointsinpolygon', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['Cnt_zdrowie'] = outputs['PoliczPunktyWPoligonie_2']['OUTPUT']

        feedback.setCurrentStep(6)
        if feedback.isCanceled():
            return {}

        # Policz punkty w poligonie
        alg_params = {
            'CLASSFIELD': None,
            'FIELD': 'cnt_handel',
            'POINTS': parameters['poi_handel'],
            'POLYGONS': outputs['PoliczPunktyWPoligonie_2']['OUTPUT'],
            'WEIGHT': None,
            'OUTPUT': parameters['Cnt_handel']
        }
        outputs['PoliczPunktyWPoligonie_3'] = processing.run('native:countpointsinpolygon', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['Cnt_handel'] = outputs['PoliczPunktyWPoligonie_3']['OUTPUT']

        feedback.setCurrentStep(7)
        if feedback.isCanceled():
            return {}

        # Policz punkty w poligonie
        alg_params = {
            'CLASSFIELD': None,
            'FIELD': 'cnt_zielen',
            'POINTS': parameters['poi_zielen'],
            'POLYGONS': outputs['PoliczPunktyWPoligonie_3']['OUTPUT'],
            'WEIGHT': None,
            'OUTPUT': parameters['Cnt_zielen']
        }
        outputs['PoliczPunktyWPoligonie_4'] = processing.run('native:countpointsinpolygon', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['Cnt_zielen'] = outputs['PoliczPunktyWPoligonie_4']['OUTPUT']

        feedback.setCurrentStep(8)
        if feedback.isCanceled():
            return {}

        # Policz punkty w poligonie
        alg_params = {
            'CLASSFIELD': None,
            'FIELD': 'cnt_transport',
            'POINTS': parameters['poi_transport'],
            'POLYGONS': outputs['PoliczPunktyWPoligonie_4']['OUTPUT'],
            'WEIGHT': None,
            'OUTPUT': parameters['Cnt_transport']
        }
        outputs['PoliczPunktyWPoligonie_5'] = processing.run('native:countpointsinpolygon', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['Cnt_transport'] = outputs['PoliczPunktyWPoligonie_5']['OUTPUT']

        feedback.setCurrentStep(9)
        if feedback.isCanceled():
            return {}

        # Kalkulator p�l
        alg_params = {
            'FIELD_LENGTH': 10,
            'FIELD_NAME': 'index_15m',
            'FIELD_PRECISION': 1,
            'FIELD_TYPE': 0,  # Liczba dziesi�tna (double)
            'FORMULA': '(\r\n  (if("cnt_edukacja" > 0, 1, 0) * 3) +\r\n  (if("cnt_zdrowie" > 0, 1, 0) * 3) +\r\n  (if("cnt_handel" > 0, 1, 0) * 2) +\r\n  (if("cnt_zielen" > 0, 1, 0) * 2) +\r\n  (if("cnt_transport" > 0, 1, 0) * 1)\r\n) / 11.0 * 100.0',
            'INPUT': outputs['PoliczPunktyWPoligonie_5']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['KalkulatorPl'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(10)
        if feedback.isCanceled():
            return {}

        # Z��cz atrybuty wed�ug warto�ci pola
        alg_params = {
            'DISCARD_NONMATCHING': False,
            'FIELD': 'id',
            'FIELDS_TO_COPY': [''],
            'FIELD_2': 'id',
            'INPUT': outputs['Przytnij']['OUTPUT'],
            'INPUT_2': outputs['KalkulatorPl']['OUTPUT'],
            'METHOD': 1,  # przyjmuj atrybuty tylko z pierwszego pasuj�cego obiektu (jeden do jednego)
            'PREFIX': None,
            'OUTPUT': parameters['Siatka_analiza_15m']
        }
        outputs['ZczAtrybutyWedugWartociPola'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['Siatka_analiza_15m'] = outputs['ZczAtrybutyWedugWartociPola']['OUTPUT']
        return results

    def name(self) -> str:
        return 'Analiza_dostepnosci_15m'

    def displayName(self) -> str:
        return 'Analiza_dostepnosci_15m'

    def group(self) -> str:
        return ''

    def groupId(self) -> str:
        return ''

    def createInstance(self):
        return self.__class__()
